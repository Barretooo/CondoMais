<?php

	include "banco.php";
	include "util.php";

	$cdrese = $_POST["cdrese"];
	$cdarea = $_POST["cdarea"];
	$cdusua = $_POST["cdusua"];
	$dtrese = $_POST["dtrese"];
	$hrrese = $_POST["hrrese"];
	$deobse = $_POST["deobse"];
	$flativ	= $_POST["flativ"];
	$dtcada = date('Y-m-d');

	$Flag = true;

	$hrinic = $hrrese - 2;
	$hrfina = $hrrese + 4;

    $sql = "select * from reservas where cdrese <> $cdrese and cdarea = '{$cdarea}' and dtrese = '{$dtrese}' and hrrese >= '{hrinic}' and hrrese <= '{hrfina}'";
    $aRese= ConsultarDados("", "", "", $sql);
    if (count($aRese) > 0 ){
		$demens = "Já existe reserva para essa área nessa data e hora!";
		$detitu = "CondoMais&copy; | Aprovar Reservas";
		$devolt = "aprovarra.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
		$Flag=false;
    }

	switch (get_post_action('edita','apaga')) {
    case 'edita':

		if ($Flag == true){

			//campos da tabela
			$aNomes=array();
			//$aNomes[]= "cdrese";
			$aNomes[]= "cdarea";
			$aNomes[]= "cdusua";
			$aNomes[]= "dtrese";
			$aNomes[]= "hrrese";
			$aNomes[]= "deobse";
			$aNomes[]= "flativ";
			$aNomes[]= "dtcada";
		
			//dados da tabela
			$aDados=array();
			//$aDados[]= $cdrese;
			$aDados[]= $cdarea;
			$aDados[]= $cdusua;
			$aDados[]= $dtrese;
			$aDados[]= $hrrese;
			$aDados[]= $deobse;
			$aDados[]= $flativ;
			$aDados[]= $dtcada;

			AlterarDados("reservas", $aDados, $aNomes,"cdrese", $cdrese);

			$demens = "Atualização efetuada com sucesso!";

		}

		break;
    case 'apaga':
		$demens = "Exclusão efetuada com sucesso!";

		ExcluirDados("reservas", "cdrese", $cdrese);

		break;
    default:
		$deeven = "Ocorreu um problema na atualização/exclusão. Se persistir contate o suporte!";
	}

	//gravar log
	GravarLog($cdusua, "Alteração de dados da reserva -> {$cdrese}");

	if ($Flag == true) {
		$detitu = "CondoMais&copy; | Aprovar Reservas";
		$devolt = "aprovarr.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
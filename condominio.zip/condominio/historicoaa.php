<?php

	include "banco.php";
	include "util.php";

	$nrsequ = $_POST["nrsequ"];

	$Flag = true;

	if ($Flag == true) {

		switch (get_post_action('edita','apaga')) {
	    case 'edita':

			break;
	    case 'apaga':
			$demens = "Exclusão efetuada com sucesso!";

			ExcluirDados("log", "nrsequ", $nrsequ);

			break;
	    default:
			$demens = "Ocorreu um problema na atualização/exclusão. Se persistir contate o Suporte!";
		}

		$detitu = "CondoMais&copy; | Histórico de Ações";
		$devolt = "historico.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
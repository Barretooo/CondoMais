<?php

	include "banco.php";
	include "util.php";

	$cdeven = $_POST["cdeven"];
	$deeven = $_POST["deeven"];
	$fllido = $_POST["fllido"];
	$flmaie = $_POST["flmaie"];
	$cdusuo = $_POST["cdusuo"];
	$cdusud = $_POST["cdusud"];
	$dteven = $_POST["dteven"];
	$hreven = $_POST["hreven"];
	$dtcada = date('Y-m-d');
	$flativ	= 'S';

	$Flag = true;

	if ($Flag == true) {

		//campos da tabela
		$aNomes=array();
		$aNomes[]= "cdeven";
		$aNomes[]= "deeven";
		$aNomes[]= "fllido";
		$aNomes[]= "flmaie";
		$aNomes[]= "cdusuo";
		$aNomes[]= "cdusud";
		$aNomes[]= "dtcada";
		$aNomes[]= "flativ";
		$aNomes[]= "dteven";
		$aNomes[]= "hreven";
	
		//dados da tabela
		$aDados=array();
		$aDados[]= $cdeven;
		$aDados[]= $deeven;
		$aDados[]= $fllido;
		$aDados[]= $flmaie;
		$aDados[]= $cdusuo;
		$aDados[]= $cdusud;
		$aDados[]= $dtcada;
		$aDados[]= $flativ;
		$aDados[]= $dteven;
		$aDados[]= $hreven;

		IncluirDados("eventos", $aDados, $aNomes);

		$demens = "Cadastro efetuado com sucesso!";
		$detitu = "CondoMais&copy; | Eventos";
		$devolt = "eventos.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
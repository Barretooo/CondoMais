<?php

function ExcluirDados($tabela, $campo, $chave, $sql="") {
    include "conexao.php";

    if (empty($sql)) {
       $sql = "delete from "."{$tabela}"." where "."{$campo}"." = "."'{$chave}'";
    }

    mysqli_query($conexao, $sql);
    mysqli_close($conexao);

    $xtabela = TrazNomeArquivo($tabela);

    if (empty($xtabela) == false) {
        $cdusua="99999999999";
        $delog = "Exclusão dos dados da tabela ["."{$xtabela}"."] para a chave ["."{$chave}"."]";
        if (isset($_COOKIE['cdusua'])) {
            $cdusua = $_COOKIE['cdusua'];
        }

        if ($tabela !== "log") {
            GravarLog($cdusua, $delog);       
        }
    }

    return;
}

function ConsultarDados($tabela, $campo, $chave, $sql="") {
    include 'conexao.php';

    if (empty($sql)) {
        $sql = "select * from "."{$tabela}"." where "."{$campo}"." = "."'{$chave}'";
    }

    $aDados=array();

    $resultado=mysqli_query($conexao, $sql);

    if ($resultado) {
        while ($linha = mysqli_fetch_assoc($resultado)) {
            $aDados[]=$linha;
        }
    }

    mysqli_close($conexao);
    return ($aDados);
}

function AlterarDados($tabela, $dados, $nomes=null, $campo=null, $chave=null, $sql="") {
    include "conexao.php";

    if (empty($sql) == true) {

        $campos="";
        $total=count($dados)-1;

        $sql="update "."{$tabela}"." set ";
 
        for ($i =0 ; $i < count($dados) ; $i++ ) {

            $campos=$campos.$nomes[$i]." = '".$dados[$i]."'";
        
            if ($i < $total) {
                $campos=$campos.", ";
            }

        }
        if ($tabela !== "parametros"){
            $sql=$sql.$campos." where  ".$campo." = "."'{$chave}'";
        } Else {
            $sql=$sql.$campos;
        }
    }

    mysqli_query($conexao, $sql);
    mysqli_close($conexao);

    $xtabela = TrazNomeArquivo($tabela);

    if (empty($xtabela) == false) {
        $cdusua="99999999999";
        $delog = "Alteração dos dados da tabela ["."{$xtabela}"."] para a chave ["."{$chave}"."]";
        if (isset($_COOKIE['cdusua'])) {
            $cdusua = $_COOKIE['cdusua'];
        }

        if ($tabela !== "log") {
            GravarLog($cdusua, $delog);       
        }
    }

    return;
}


function IncluirDados($tabela, $dados=null, $nomes=null, $sql="") {
    include "conexao.php";

    if (empty($sql) == true) {

        $sql="insert into "."{$tabela}"." (";
        $campos="";
        $total=count($nomes)-1;

        for ($i=0 ; $i < count($nomes) ; $i++ ) {

            $campos=$campos.$nomes[$i];
        
            if ($i < $total) {
                $campos=$campos.", ";
            }

        }
        
        $sql=$sql.$campos.") values (";

        $campos="";

        for ($x =0 ; $x < count($dados) ; $x++ ) {

            $campo="'".$dados[$x]."'";
        
            if ($x < $total) {
                $campos=$campos.$campo.", ";
            } Else {
                $campos=$campos.$campo.")";
            }
        }
    }

    $sql=$sql.$campos;

    mysqli_query($conexao, $sql);
    mysqli_close($conexao);

    $xtabela = TrazNomeArquivo($tabela);

    if (empty($xtabela) == false) {
        $cdusua="99999999999";
        $delog = "Inclusão dos dados da tabela ["."{$xtabela}"."] para ["."{$dados[0]}"."]";
        if (isset($_COOKIE['cdusua'])) {
            $cdusua = $_COOKIE['cdusua'];
        }

        if ($tabela !== "log") {
            GravarLog($cdusua, $delog);       
        }
    }

    return;
}

function IncluirDadosLOG($tabela, $dados=null, $nomes=null, $sql="") {
    include "conexao.php";

    if (empty($sql) == true) {

        $sql="insert into "."{$tabela}"." (";
        $campos="";
        $total=count($nomes)-1;

        for ($i=0 ; $i < count($nomes) ; $i++ ) {

            $campos=$campos.$nomes[$i];
        
            if ($i < $total) {
                $campos=$campos.", ";
            }

        }
        
        $sql=$sql.$campos.") values (";

        $campos="";

        for ($x =0 ; $x < count($dados) ; $x++ ) {

            $campo="'".$dados[$x]."'";
        
            if ($x < $total) {
                $campos=$campos.$campo.", ";
            } Else {
                $campos=$campos.$campo.")";
            }
        }
    }

    $sql=$sql.$campos;

    mysqli_query($conexao, $sql);
    mysqli_close($conexao);

    return;
}

function GravarNovaSenha($cdusua, $demail, $desenh) {
    include "conexao.php";

    $sql="update usuarios set desenh = "."'{$desenh}'"." where demail = "."'{$demail}' and cdusua = '{$cdusua}'";

    mysqli_query($conexao, $sql);
    mysqli_close($conexao);
    return;
}

function BuscaSoli($cdusua, $data){
    include "conexao.php";

    $sql = "select cdsoli from solicitacoes where cdusud = '{$cdusua}' and dtcada = '{$data}'";

    $cdsoli="";

    $resultado=mysqli_query($conexao, $sql);

    if ($resultado) {
        while ($linha = mysqli_fetch_assoc($resultado)) {
            $cdsoli=$linha["cdsoli"];
        }
    }

    mysqli_close($conexao);
    return ($cdsoli);
}

function Acesso($cdmenu="00", $cdusua="00000000000"){
    include "conexao.php";
    $Acesso=false;

    $sql = "select * from acessos where cdmenu = '{$cdmenu}' and cdusua = '{$cdusua}'"; 
    $resultado=mysqli_query($conexao, $sql);

    if ($resultado) {
        while ($linha = mysqli_fetch_assoc($resultado)) {
            $Acesso=true;
        }
    }

    mysqli_close($conexao);
    return ($Acesso);
}

Function UltimoDownload($dearqu="", $cdclie="") {
    include "conexao.php";
    $mensagem="";

    //$sql = "select MAX(dtdown) dtdown from download where dearqu = '{$dearqu}' and cdclie = '{$cdclie}'";
    // exemplo de acesso ao banco de dados
    $sql = "SELECT * FROM download";
    $resultado=mysqli_query($conexao, $sql);

    if ($resultado) {
        while ($linha = mysqli_fetch_assoc($resultado)) {
            $dtdown = $linha['dtdown'];
            $dtdown = strtotime($dtdown);
            if (empty($dtdown) == true){
                $dtdown = date('d-m-Y H:i:s', $dtdown);
                $mensagem = "Download em {$dtdown}";
                //$mensagem = "A = ".$dearqu." - ".$cdclie;
            }
        }
    }

    mysqli_close($conexao);
    return ($mensagem);    
}


function BuscaConta($nrano, $nrmes, $cdtipo){
    include "conexao.php";

    if ($cdtipo == 'P'){
        $sql = "SELECT sum(vlpaga) 'valor' FROM `pagar` WHERE year(dtpaga) = {$nrano} and month(dtpaga) = {$nrmes}";
    } Else {
        $sql = "SELECT sum(vlrece) 'valor' FROM `receber` WHERE year(dtrece) = {$nrano} and month(dtrece) = {$nrmes}";
    }

    $valor=0.00;

    $resultado=mysqli_query($conexao, $sql);

    if ($resultado) {
        while ($linha = mysqli_fetch_assoc($resultado)) {
            $valor=$linha["valor"];
        }
    }

    if (empty($valor)==true){
        $valor=0.00;
    }

    mysqli_close($conexao);
    return ($valor);
}

?>
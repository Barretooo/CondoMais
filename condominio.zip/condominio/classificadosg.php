<?php

	include "banco.php";
	include "util.php";

	$cdclas = $_POST["cdclas"];
	$declas = $_POST["declas"];
	$fllido = $_POST["fllido"];
	$flmaie = $_POST["flmaie"];
	$cdusuo = $_POST["cdusuo"];
	$cdusud = $_POST["cdusud"];
	$dtcada = date('Y-m-d');
	$flativ	= 'S';

	$Flag = true;

	if ($Flag == true) {

		//campos da tabela
		$aNomes=array();
		$aNomes[]= "cdclas";
		$aNomes[]= "declas";
		$aNomes[]= "fllido";
		$aNomes[]= "flmaie";
		$aNomes[]= "cdusuo";
		$aNomes[]= "cdusud";
		$aNomes[]= "dtcada";
		$aNomes[]= "flativ";
	
		//dados da tabela
		$aDados=array();
		$aDados[]= $cdclas;
		$aDados[]= $declas;
		$aDados[]= $fllido;
		$aDados[]= $flmaie;
		$aDados[]= $cdusuo;
		$aDados[]= $cdusud;
		$aDados[]= $dtcada;
		$aDados[]= $flativ;

		IncluirDados("classificados", $aDados, $aNomes);

		if ($flmaie == 'S'){
		    $aPara = ConsultarDados("", "", "","select * from parametros");
		    $dequem="dequem@hotmail.com";
		    if (count($aPara) > 0 ) {
		        $dequem=$aPara[0]["demail"];
		    }

		    $aUsua = ConsultarDados("usuarios", "cdusua", $cdusud);
		    $paraquem="paraquem@hotmail.com";
		    $cdusua="00000000000";
		    $deusua="Nome do Usuário";
		    if (count($aUsua) > 0 ) {
		        $paraquem=$aUsua[0]["demail"];
		        $cdusua=$aUsua[0]["cdusua"];
		        $deusua=$aUsua[0]["deusua"];
		    }

		    $assunto = "CondominioLIGHT | Confirmação de Anúncio Classificados";
		    $declas = "Olá {$deusua}, <br /> Seu anúncio foi gravado. Acesse o sistema e veja seu anúncio! <br /> Abraços";

		    EnviarEmail($paraquem, $dequem, $assunto, $declas);

		}

		$demens = "Cadastro efetuado com sucesso!";
		$detitu = "Condomínio Light&copy; | Cadastro de Anúncios Classificados";
		$devolt = "classificados.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
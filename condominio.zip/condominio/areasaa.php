<?php

	include "banco.php";
	include "util.php";

	$cdarea = $_POST["cdarea"];
	$dearea = $_POST["dearea"];
	$deobse = $_POST["deobse"];
	$dtcada = date('Y-m-d');
	$flativ	= "S";

    //codigo do usuario
    if (isset($_COOKIE['cdusua'])) {
        $cdusua = $_COOKIE['cdusua'];
    } Else {
    	$cdusua = "99999999999";
    }

	$Flag = true;

	switch (get_post_action('edita','apaga')) {
    case 'edita':

		if ($Flag == true){

			$demens = "Atualização efetuada com sucesso!";

			//campos da tabela
			$aNomes=array();
			//$aNomes[]= "cdusua";
			$aNomes[]= "dearea";
			$aNomes[]= "deobse";
			$aNomes[]= "dtcada";
			$aNomes[]= "flativ";
		
			//dados da tabela
			$aDados=array();
			//$aDados[]= $cdusua;
			$aDados[]= $dearea;
			$aDados[]= $deobse;
			$aDados[]= $dtcada;
			$aDados[]= $flativ;

			AlterarDados("areas", $aDados, $aNomes,"cdarea", $cdarea);

		}


		break;
    case 'apaga':
		$demens = "Exclusão efetuada com sucesso!";

		ExcluirDados("areas", "cdarea", $cdarea);

		break;
    default:
		$demens = "Ocorreu um problema na atualização/exclusão. Se persistir contate o suporte!";
	}

	//gravar log
	GravarLog($cdusua, "Alteração de dados da área comum -> {$cdarea} - {$dearea}");
	if ($Flag == true) {
		$detitu = "CondoMais&copy; | Cadastro de Áreas Comuns";
		$devolt = "areas.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
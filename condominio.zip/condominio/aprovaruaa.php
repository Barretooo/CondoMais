<?php

	include "banco.php";
	include "util.php";

	$cdusua = $_POST["cdusua"];
	$deusua = $_POST["deusua"];
	//$desenh = substr($_POST["cdusua"], 0, 3);
	$demail = $_POST["demail"];
	$nrrama = $_POST["nrrama"];
	$nrtele = $_POST["nrtele"];
	$nrcelu = $_POST["nrcelu"];
	$deloca = $_POST["deloca"];
	$cdtipo = $_POST["cdtipo"];
	$defoto = "";
	$deobse = $_POST["deobse"];
	$dtcada = date('Y-m-d');
	$flativ	= $_POST["flativ"];

	$Flag = true;

	switch ($cdtipo) {
		case 'A':
			$cdtipo="Administrador";
			break;
		case 'M':
			$cdtipo="Morador";
			break;
		case 'F':
			$cdtipo="Funcionário";
			break;
		
		default:
			$cdtipo="";
			break;
	}

	$cdusua=RetirarMascara($cdusua,"cpf");

	$defoto1 = $_POST["defoto1"];
	$demaila = $_POST["demaila"];

	switch (get_post_action('edita','apaga')) {
    case 'edita':

		if ($demaila !== $demail) {
			$aTrab = ConsultarDados("usuarios", "demail", $demail);
			if ( count($aTrab) > 0) {
				$demens = "E-Mail informado já cadastrado!";
				$detitu = "CondoMais&copy; | Aprovação de Usuários";
				header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu);
				$Flag=false;
			}
		}

		if ($Flag == true){
			//uploads
			$uploaddir = 'img/'.$cdusua."_";
			$uploadfile1 = $uploaddir . basename($_FILES['defoto']['name']);

		    #Move o arquivo para o diretório de destino
		    move_uploaded_file( $_FILES["defoto"]["tmp_name"], $uploadfile1 );

			$defoto=basename($_FILES['defoto']['name']);

			if (empty($defoto) == true) {
				$defoto= $defoto1;
			} Else {
				$defoto= $uploadfile1;
			}

			$demens = "Atualização efetuada com sucesso!";

			//campos da tabela
			$aNomes=array();
			//$aNomes[]= "cdusua";
			$aNomes[]= "deusua";
			//$aNomes[]= "desenh";
			$aNomes[]= "demail";
			$aNomes[]= "nrrama";
			$aNomes[]= "nrtele";
			$aNomes[]= "nrcelu";
			$aNomes[]= "deloca";
			$aNomes[]= "cdtipo";
			$aNomes[]= "defoto";
			$aNomes[]= "deobse";
			$aNomes[]= "dtcada";
			$aNomes[]= "flativ";
		
			//dados da tabela
			$aDados=array();
			//$aDados[]= $cdusua;
			$aDados[]= $deusua;
			//$aDados[]= md5($desenh);
			$aDados[]= $demail;
			$aDados[]= $nrrama;
			$aDados[]= $nrtele;
			$aDados[]= $nrcelu;
			$aDados[]= $deloca;
			$aDados[]= $cdtipo;
			$aDados[]= $defoto;
			$aDados[]= $deobse;
			$aDados[]= $dtcada;
			$aDados[]= $flativ;

			AlterarDados("usuarios", $aDados, $aNomes,"cdusua", $cdusua);

		}


		break;
    case 'apaga':
		$demens = "Exclusão efetuada com sucesso!";

		ExcluirDados("usuarios", "cdusua", $cdusua);
    	ExcluirDados("acessos", "cdusua", $cdusua);

		break;
    default:
		$demens = "Ocorreu um problema na atualização/exclusão. Se persistir contate o suporte!";
	}

	//gravar log
	GravarLog($cdusua, "Alteração de dados do Usuário -> {$cdusua} - {$deusua}");
	if ($Flag == true) {
		$detitu = "CondoMais&copy; | Aprovação de Usuários";
		$devolt = "aprovaru.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
<?php

	include "banco.php";
	include "util.php";

	$cdarqu = $_POST["cdarqu"];
	$cdusud = $_POST["cdusud"];
	$dearqu = $_POST["dearqu"];
	$deobse = $_POST["deobse"];
	$dtcada = date('Y-m-d');
	$flativ	= "S";

    //codigo do usuario
    if (isset($_COOKIE['cdusua'])) {
        $cdusua = $_COOKIE['cdusua'];
    } Else {
    	$cdusua = "99999999999";
    }

	$Flag = true;

	switch (get_post_action('edita','apaga')) {
    case 'edita':

		if ($Flag == true){

			$demens = "Atualização efetuada com sucesso!";

			//campos da tabela
			$aNomes=array();
			$aNomes[]= "cdusud";
			$aNomes[]= "dearqu";
			$aNomes[]= "deobse";
		
			//dados da tabela
			$aDados=array();
			$aDados[]= $cdusud;
			$aDados[]= $dearqu;
			$aDados[]= $deobse;

			AlterarDados("arquivos", $aDados, $aNomes,"cdarqu", $cdarqu);

		}

		break;
    case 'apaga':
		$demens = "Exclusão efetuada com sucesso!";

		ExcluirDados("arquivos", "cdarqu", $cdarqu);

		break;
    default:
		$demens = "Ocorreu um problema na atualização/exclusão. Se persistir contate o suporte!";
	}

	//gravar log
	GravarLog($cdusua, "Alteração de dados de Boletos  -> {$cdarqu} - {$dearqu}");
	if ($Flag == true) {
		$detitu = "CondoMais&copy; | Cadastro de Boletos";
		$devolt = "boletos.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
<?php
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Cache-Control: no-cache");
    header("Pragma: no-cache");


    // identificando dispositivo
    $iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    $ipad = strpos($_SERVER['HTTP_USER_AGENT'],"iPad");
    $android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
    $palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
    $berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
    $ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
    $symbian =  strpos($_SERVER['HTTP_USER_AGENT'],"Symbian");

    $eMovel="N";
    if ($iphone || $ipad || $android || $palmpre || $ipod || $berry || $symbian == true) {
        $eMovel="S";
    }

    // incluindo bibliotecas de apoio
    include "banco.php";
    include "util.php";

    //codigo do usuario
    if (isset($_COOKIE['cdusua'])) {
        $cdusua = $_COOKIE['cdusua'];
    } Else {
        header('Location: index.html');
    }

    // nome do usuario
    if (isset($_COOKIE['deusua'])) {
        $deusua = $_COOKIE['deusua'];
    } Else {
        header('Location: index.html');
    }

    //localização da foto
    if (isset($_COOKIE['defoto'])) {
        $defoto = $_COOKIE['defoto'];
    }

    //tipo de usuario
    if (isset($_COOKIE['cdtipo'])) {
        $cdtipo = $_COOKIE['cdtipo'];
    }

    //email de usuario
    if (isset($_COOKIE['demail'])) {
        $demail = $_COOKIE['demail'];
    }

    $detipo=TrazTipo($cdtipo);

    // reduzir o tamanho do nome do usuario
    $deusua1=$deusua;
    $deusua = substr($deusua, 0,25);

    $sql = "select a.* from livros a order by a.cdusuo, a.cdlivr";

    if ($cdtipo == 'X'){
        $sql = "select a.* from livros a where (a.cdusuo = '{$cdusua}' or a.cdusud = '{$cdusua}') order by a.cdusuo, a.cdlivr";
    }

    $aMens= ConsultarDados("", "", "", $sql);
    if (count($aMens) == 0 ){
        echo 'Dados dos livros não foram encontrados. Contacte o suporte técnico!';
        die();
    }

    $aPara = ConsultarDados('','','','select * from parametros');
    if (count($aPara) > 0 ){
        $cdclie =   $aPara[0]['cdclie'];
        $declie =   $aPara[0]['declie'];
    } Else {
        echo 'Dados do condomínio não foram encontrados. Contacte o suporte técnico!';
        die();
    }

?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CondoMais&copy; | Principal </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                                <img alt="foto" width="80" height="80" class="img-circle" src="<?php echo $defoto; ?>" />
                                 </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $deusua; ?></strong>
                                 </span> <span class="text-muted text-xs block"><?php echo $detipo; ?><b class="caret"></b></span> </span> </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="meusdados.php">Atualizar Meus Dados</a></li>
                                <li><a href="minhasenha.php">Alterar Minha Senha</a></li>
                                <li class="divider"></li>
                                <li><a href="index.html">Sair</a></li>
                            </ul>
                        </div>
                    </li>

                    <li>
                        <a href="index.php"><i class="fa fa-home"></i> <span class="nav-label">Menu Principal</span></a>
                    </li>                    

                </ul>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                    </div>
                    <ul class="nav navbar-top-links navbar-left">
                        <br>
                        <li>
                            <span class="m-r-sm text-muted welcome-message fa fa-home"> <?php echo formatar($cdclie,"cnpj")." - ".$declie;?></span>
                        </li>
                    </ul>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <span class="m-r-sm text-muted welcome-message">Bem-vindo ao <strong>CondoMais&copy;</strong></span>
                        </li>
                        <li>
                            <a href="index.html">
                                <i class="fa fa-sign-out"></i> Sair
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="wrapper wrapper-content">
                <!--div class="col-lg-12"-->
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <button type="button" class="btn btn-primary btn-lg btn-block"><i
                                                        class="fa fa-book"></i> Livro de Ocorrências
                            </button>
                        </div>

                        <div class="ibox-content">
                            <?php if ($cdtipo !== 'X'){?>
                                <div class="pull-left">
                                    <a onclick="#" href="livrosi.php" class="btn btn-primary ">Incluir</a>
                                </div>
                                <br>
                                <br>
                            <?php }?>
                            <br>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-example" >
                                    <thead>
                                        <tr>
                                            <th><center>Sequencial</center></th>
                                            <th><center>Descrição</center></th>
                                            <th><center>Morador</center></th>
                                            <th><center>Celular</center></th>
                                            <th><center>E-mail</center></th>
                                            <th class="text-right" data-sort-ignore="true"><center>Ação</center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php for ($f =0; $f <= (count($aMens)-1); $f++) { ?>
                                            <tr class="gradeX">

                                                <?php $coluna1 = $aMens[$f]["cdlivr"]; ?>
                                                <?php $coluna2 = $aMens[$f]["delivr"]; ?>
                                                <?php $coluna3 = $aMens[$f]["cdusuo"]; ?>

                                                <?php $cdusuo = $aMens[$f]["cdusuo"]; ?>

                                                <?php $aUsua= ConsultarDados("usuarios", "cdusua", $coluna3); ?>
                                                <?php if (count($aUsua)>0) {?>
                                                    <?php $coluna3 = $aUsua[0]["cdusua"]." - ".substr($aUsua[0]["deusua"],0,30); ?>    
                                                    <?php $coluna4 = $aUsua[0]["nrcelu"]; ?>
                                                    <?php $coluna5 = $aUsua[0]["demail"]; ?>
                                                <?php }?>

                                                <?php $ver = "livrosa.php?acao=ver&chave=".$coluna1; ?>
                                                <?php $edita = "livrosa.php?acao=edita&chave=".$coluna1; ?>
                                                <?php $apaga = "livrosa.php?acao=apaga&chave=".$coluna1; ?>

                                                <td><center><?php print $coluna1; ?></center></td>
                                                <td><center><?php print $coluna2; ?></center></td>
                                                <td><center><?php print $coluna3; ?></center></td>
                                                <td><center><?php print $coluna4; ?></center></td>
                                                <td><center><?php print $coluna5; ?></center></td>
                                                <?php if ($cdtipo !== 'X'){?>
                                                    <td class="text-right">
                                                        <div class="btn-group">
                                                            <button class="fa fa-eye btn-white btn btn-xs" name="ver" type="button" onclick="window.open('<?php echo $ver;?>','_parent')"></button>
                                                            <?php if ($cdusuo == $cdusua){?>
                                                                <button class="fa fa-edit btn-white btn btn-xs" name="edita" type="button" onclick="window.open('<?php echo $edita;?>','_parent')"></button>
                                                                <button class="fa fa-trash btn-white btn btn-xs" name="apaga" type="button" onclick="window.open('<?php echo $apaga;?>','_parent')"></button>
                                                            <?php }?>
                                                        </div>
                                                    </td>
                                                <?php }?>
                                            </tr>
                                        <?php }; ?>    
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th><center>Sequencial</center></th>
                                            <th><center>Descrição</center></th>
                                            <th><center>Morador</center></th>
                                            <th><center>Celular</center></th>
                                            <th><center>E-mail</center></th>
                                            <th class="text-right" data-sort-ignore="true"><center>Ação</center></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <br>
                        </div>
                    </div>
                <!--/div-->
            </div>
        </div>
    </div>
    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <script src="js/plugins/jeditable/jquery.jeditable.js"></script>
    <script src="js/plugins/dataTables/datatables.min.js"></script>

    <!-- Peity -->
    <script src="js/plugins/peity/jquery.peity.min.js"></script>
    <script src="js/demo/peity-demo.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- jQuery UI -->
    <script src="js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- Jvectormap -->
    <script src="js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- EayPIE -->
    <script src="js/plugins/easypiechart/jquery.easypiechart.js"></script>

    <!-- Sparkline -->
    <script src="js/plugins/sparkline/jquery.sparkline.min.js"></script>

    <!-- Sparkline demo data  -->
    <script src="js/demo/sparkline-demo.js"></script>

    <script>

        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    {extend: 'pdf', title: 'Ocorrências'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });

            /* Init DataTables */
            var oTable = $('#editable').DataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );


        });

    </script>
</body>
</html>

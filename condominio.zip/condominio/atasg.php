<?php

	include "banco.php";
	include "util.php";

	$cdarqu = $_POST["cdarqu"];
	$dearqu = $_POST["dearqu"];
	$deobse = $_POST["deobse"];
	$dtcada = date('Y-m-d');
	$flativ	= "S";

    if (isset($_COOKIE['cdusua'])) {
        $cdusua = $_COOKIE['cdusua'];
    } Else {
    	$cdusua = "99999999999";
    }

	$Flag = true;

	if ($Flag == true) {

		//uploads
		$uploaddir = 'arquivos/';
		$uploadfile1 = $uploaddir . $_FILES['decami']['name'];

	    #Move o arquivo para o diretório de destino
	    move_uploaded_file( $_FILES["decami"]["tmp_name"], $uploadfile1 );

		$decami=$_FILES['decami']['name'];

		if (empty($decami) == true){
		  $decami="arquivos/semconteudo.txt";
		} Else {
		  $decami=$uploadfile1;
		}

		//campos da tabela
		$aNomes=array();
		//$aNomes[]= "cdarqu";
		$aNomes[]= "dearqu";
		$aNomes[]= "decami";
		$aNomes[]= "deobse";
		$aNomes[]= "cdusuo";
		$aNomes[]= "cdusud";
		$aNomes[]= "cdtipo";
		$aNomes[]= "dtcada";
		$aNomes[]= "flativ";
	
		//dados da tabela
		$aDados=array();
		//$aDados[]= $cdarqu;
		$aDados[]= $dearqu;
		$aDados[]= $decami;
		$aDados[]= $deobse;
		$aDados[]= $cdusua;
		$aDados[]= "99999999999";
		$aDados[]= "A";
		$aDados[]= $dtcada;
		$aDados[]= $flativ;

		IncluirDados("arquivos", $aDados, $aNomes);

		$demens = "Cadastro efetuado com sucesso!";
		$detitu = "CondoMais&copy; | Cadastro de Atas de Reuniões";
		$devolt = "atas.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
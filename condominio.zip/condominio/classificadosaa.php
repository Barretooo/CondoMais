<?php

	include "banco.php";
	include "util.php";

	$cdclas = $_POST["cdclas"];
	$declas = $_POST["declas"];
	$fllido = $_POST["fllido"];
	$flmaie = $_POST["flmaie"];
	$cdusuo = $_POST["cdusuo"];
	$cdusud = $_POST["cdusud"];
	$dtcada = date('Y-m-d');
	$flativ	= 'S';

	$Flag = true;

	switch (get_post_action('edita','apaga')) {
    case 'edita':

		if ($Flag == true){

			//campos da tabela
			$aNomes=array();
			//$aNomes[]= "cdclas";
			$aNomes[]= "declas";
			$aNomes[]= "fllido";
			$aNomes[]= "flmaie";
			$aNomes[]= "cdusuo";
			$aNomes[]= "cdusud";
			//$aNomes[]= "dtcada";
			$aNomes[]= "flativ";
		
			//dados da tabela
			$aDados=array();
			//$aDados[]= $cdclas;
			$aDados[]= $declas;
			$aDados[]= $fllido;
			$aDados[]= $flmaie;
			$aDados[]= $cdusuo;
			$aDados[]= $cdusud;
			//$aDados[]= $dtcada;
			$aDados[]= $flativ;

			AlterarDados("classificados", $aDados, $aNomes,"cdclas", $cdclas);

			if ($flmaie == 'S'){
			    $aPara = ConsultarDados("", "", "","select * from parametros");
			    $dequem="dequem@hotmail.com";
			    if (count($aPara) > 0 ) {
			        $dequem=$aPara[0]["demail"];
			    }

			    $aUsua = ConsultarDados("usuarios", "cdusua", $cdusud);
			    $paraquem="paraquem@hotmail.com";
			    $cdusua="00000000000";
			    $deusua="Nome do Usuário";
			    if (count($aUsua) > 0 ) {
			        $paraquem=$aUsua[0]["demail"];
			        $cdusua=$aUsua[0]["cdusua"];
			        $deusua=$aUsua[0]["deusua"];
			    }

			    $assunto = "CondominioLIGHT | Tem Mensagem Para Você";
			    $demens = "Olá {$deusua}, <br /> Acesse o sistema e veja a mensagem! <br /> Abraços";

			    EnviarEmail($paraquem, $dequem, $assunto, $demens);

			}

			$demens = "Atualização efetuada com sucesso!";

		}

		break;
    case 'apaga':
		$demens = "Exclusão efetuada com sucesso!";

		ExcluirDados("classificados", "cdclas", $cdclas);

		break;
    default:
		$declas = "Ocorreu um problema na atualização/exclusão. Se persistir contate o suporte!";
	}

	//gravar log
	GravarLog($cdusua, "Alteração de dados do anúncio -> {$cdclas} - {$declas}");

	if ($Flag == true) {
		$detitu = "CondoMais&copy; | Cadastro de Anúncios Classificados";
		$devolt = "classificados.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
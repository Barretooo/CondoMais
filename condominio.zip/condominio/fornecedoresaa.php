<?php

	include "banco.php";
	include "util.php";

	$cdforn = $_POST["cdforn"];
	$deforn = $_POST["deforn"];
	$nrinsc = $_POST["nrinsc"];
	$deende = $_POST["deende"];
	$nrende = $_POST["nrende"];
	$decomp = $_POST["decomp"];
	$debair = $_POST["debair"];
	$decida = $_POST["decida"];
	$cdesta = $_POST["cdesta"];
	$nrcepi = $_POST["nrcepi"];
	$demail=  $_POST["demail"];
	$nrtele = $_POST["nrtele"];
	$nrcelu = $_POST["nrcelu"];
	$decont = $_POST["decont"];
	$dtcada = date("Y-m-d");
	$flativ = 'S';

    //codigo do usuario
    if (isset($_COOKIE['cdusua'])) {
        $cdusua = $_COOKIE['cdusua'];
    } Else {
    	$cdusua = "99999999999";
    }

	$Flag = true;

	if (strlen($cdforn) > 11){
		$cdforn=RetirarMascara($cdforn,"cnpj");
	} Else {
		$cdforn=RetirarMascara($cdforn,"cpf");
	}

	switch (get_post_action('edita','apaga')) {
    case 'edita':

		if ($Flag == true){

			$demens = "Atualização efetuada com sucesso!";

			//campos da tabela
			$aNomes=array();
			$aNomes[]= "cdforn";
			$aNomes[]= "deforn";
			$aNomes[]= "nrinsc";
			$aNomes[]= "deende";
			$aNomes[]= "nrende";
			$aNomes[]= "decomp";
			$aNomes[]= "debair";
			$aNomes[]= "decida";
			$aNomes[]= "cdesta";
			$aNomes[]= "nrcepi";
			$aNomes[]= "demail";
			$aNomes[]= "nrtele";
			$aNomes[]= "nrcelu";
			$aNomes[]= "decont";
			$aNomes[]= "dtcada";
			$aNomes[]= "flativ";

			//dados da tabela
			$aDados=array();
			$aDados[]= $cdforn;
			$aDados[]= $deforn;
			$aDados[]= $nrinsc;
			$aDados[]= $deende;
			$aDados[]= $nrende;
			$aDados[]= $decomp;
			$aDados[]= $debair;
			$aDados[]= $decida;
			$aDados[]= $cdesta;
			$aDados[]= $nrcepi;
			$aDados[]= $demail;
			$aDados[]= $nrtele;
			$aDados[]= $nrcelu;
			$aDados[]= $decont;
			$aDados[]= $dtcada;
			$aDados[]= $flativ;

			AlterarDados("fornecedores", $aDados, $aNomes,"cdforn", $cdforn);

		}

		break;
    case 'apaga':
		$demens = "Exclusão efetuada com sucesso!";

		ExcluirDados("fornecedores", "cdforn", $cdforn);

		break;
    default:
		$demens = "Ocorreu um problema na atualização/exclusão. Se persistir contate o suporte!";
	}

	//gravar log
	GravarLog($cdusua, "Alteração de dados de -> {$cdforn} - {$deforn}");
	if ($Flag == true) {
		$detitu = "CondoMais&copy; | Cadastro de Fornecedores";
		$devolt = "fornecedores.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
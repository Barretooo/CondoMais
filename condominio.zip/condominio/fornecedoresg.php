<?php

	include "banco.php";
	include "util.php";

	$cdforn = $_POST["cdforn"];
	$deforn = $_POST["deforn"];
	$nrinsc = $_POST["nrinsc"];
	$deende = $_POST["deende"];
	$nrende = $_POST["nrende"];
	$decomp = $_POST["decomp"];
	$debair = $_POST["debair"];
	$decida = $_POST["decida"];
	$cdesta = $_POST["cdesta"];
	$nrcepi = $_POST["nrcepi"];
	$demail=  $_POST["demail"];
	$nrtele = $_POST["nrtele"];
	$nrcelu = $_POST["nrcelu"];
	$decont = $_POST["decont"];
	$dtcada = date("Y-m-d");
	$flativ = 'S';

	$Flag = true;

	if (strlen($cdforn) > 11){
		$cdforn=RetirarMascara($cdforn,"cnpj");
		if ( validaCNPJ($cdforn) == false) {
			$demens = "CNPJ inválido!";
			$detitu = "CondoMais&copy; | Cadastro de Fornecedores";
			header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu);
			$Flag=false;
		}
	} Else {
		$cdforn=RetirarMascara($cdforn,"cpf");
		if ( validaCPF($cdforn) == false) {
			$demens = "CPF inválido!";
			$detitu = "CondoMais&copy; | Cadastro de Fornecedores";
			header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu);
			$Flag=false;
		}
	}

	if ($Flag == true) {

		//campos da tabela
		$aNomes=array();
		$aNomes[]= "cdforn";
		$aNomes[]= "deforn";
		$aNomes[]= "nrinsc";
		$aNomes[]= "deende";
		$aNomes[]= "nrende";
		$aNomes[]= "decomp";
		$aNomes[]= "debair";
		$aNomes[]= "decida";
		$aNomes[]= "cdesta";
		$aNomes[]= "nrcepi";
		$aNomes[]= "demail";
		$aNomes[]= "nrtele";
		$aNomes[]= "nrcelu";
		$aNomes[]= "decont";
		$aNomes[]= "dtcada";
		$aNomes[]= "flativ";

		//dados da tabela
		$aDados=array();
		$aDados[]= $cdforn;
		$aDados[]= $deforn;
		$aDados[]= $nrinsc;
		$aDados[]= $deende;
		$aDados[]= $nrende;
		$aDados[]= $decomp;
		$aDados[]= $debair;
		$aDados[]= $decida;
		$aDados[]= $cdesta;
		$aDados[]= $nrcepi;
		$aDados[]= $demail;
		$aDados[]= $nrtele;
		$aDados[]= $nrcelu;
		$aDados[]= $decont;
		$aDados[]= $dtcada;
		$aDados[]= $flativ;

		IncluirDados("fornecedores", $aDados, $aNomes);

		$demens = "Cadastro efetuado com sucesso!";
		$detitu = "CondoMais&copy; | Cadastro de Fornecedores";
		$devolt = "fornecedores.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
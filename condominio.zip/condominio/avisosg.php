<?php

	include "banco.php";
	include "util.php";

	$cdavis = $_POST["cdavis"];
	$deavis = $_POST["deavis"];
	$fllido = $_POST["fllido"];
	$flmaie = $_POST["flmaie"];
	$cdusuo = $_POST["cdusuo"];
	$cdusud = $_POST["cdusud"];
	$dtcada = date('Y-m-d');
	$flativ	= 'S';

	$Flag = true;

	if ($Flag == true) {

		//campos da tabela
		$aNomes=array();
		$aNomes[]= "cdavis";
		$aNomes[]= "deavis";
		$aNomes[]= "fllido";
		$aNomes[]= "flmaie";
		$aNomes[]= "cdusuo";
		$aNomes[]= "cdusud";
		$aNomes[]= "dtcada";
		$aNomes[]= "flativ";
	
		//dados da tabela
		$aDados=array();
		$aDados[]= $cdavis;
		$aDados[]= $deavis;
		$aDados[]= $fllido;
		$aDados[]= $flmaie;
		$aDados[]= $cdusuo;
		$aDados[]= $cdusud;
		$aDados[]= $dtcada;
		$aDados[]= $flativ;

		IncluirDados("avisos", $aDados, $aNomes);

		$demens = "Cadastro efetuado com sucesso!";
		$detitu = "CondoMais&copy; | Cadastro de Avisos";
		$devolt = "avisos.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>
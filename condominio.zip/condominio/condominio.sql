-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20-Jun-2022 às 00:20
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `condominio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acessos`
--

CREATE TABLE `acessos` (
  `cdusua` varchar(14) DEFAULT NULL,
  `cdmenu` char(2) DEFAULT NULL,
  `flaces` char(1) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `acessos`
--

INSERT INTO `acessos` (`cdusua`, `cdmenu`, `flaces`, `dtcada`, `flativ`) VALUES
('12345678910', '01', 'S', '2021-12-17', 'S'),
('12345678910', '02', 'S', '2021-12-17', 'S'),
('12345678910', '03', 'S', '2021-12-17', 'S'),
('12345678910', '04', 'S', '2021-12-17', 'S'),
('12345678910', '05', 'S', '2021-12-17', 'S'),
('12345678910', '06', 'S', '2021-12-17', 'S'),
('12345678910', '07', 'S', '2021-12-17', 'S'),
('12345678910', '08', 'S', '2021-12-17', 'S'),
('12345678910', '09', 'S', '2021-12-17', 'S'),
('12345678910', '10', 'S', '2021-12-17', 'S'),
('12345678910', '11', 'S', '2021-12-17', 'S'),
('12345678910', '12', 'S', '2021-12-17', 'S'),
('12345678910', '13', 'S', '2021-12-17', 'S'),
('12345678910', '14', 'S', '2021-12-17', 'S'),
('12345678910', '15', 'S', '2021-12-17', 'S'),
('12345678910', '16', 'S', '2021-12-17', 'S'),
('12345678910', '17', 'S', '2021-12-17', 'S'),
('12345678910', '18', 'S', '2021-12-17', 'S'),
('06931609939', '02', 'S', '2022-06-18', 'S'),
('06931609939', '03', 'S', '2022-06-18', 'S'),
('06931609939', '04', 'S', '2022-06-18', 'S'),
('06931609939', '05', 'S', '2022-06-18', 'S'),
('06931609939', '06', 'S', '2022-06-18', 'S'),
('06931609939', '07', 'S', '2022-06-18', 'S'),
('06931609939', '08', 'S', '2022-06-18', 'S'),
('06931609939', '09', 'S', '2022-06-18', 'S'),
('06931609939', '10', 'S', '2022-06-18', 'S'),
('06931609939', '11', 'S', '2022-06-18', 'S'),
('06931609939', '12', 'S', '2022-06-18', 'S'),
('06931609939', '13', 'S', '2022-06-18', 'S'),
('06931609939', '14', 'S', '2022-06-18', 'S'),
('06931609939', '15', 'S', '2022-06-18', 'S'),
('09606443930', '02', 'S', '2022-06-19', 'S'),
('09606443930', '03', 'S', '2022-06-19', 'S'),
('09606443930', '04', 'S', '2022-06-19', 'S'),
('09606443930', '05', 'S', '2022-06-19', 'S'),
('09606443930', '06', 'S', '2022-06-19', 'S'),
('09606443930', '07', 'S', '2022-06-19', 'S'),
('09606443930', '08', 'S', '2022-06-19', 'S'),
('09606443930', '09', 'S', '2022-06-19', 'S'),
('09606443930', '10', 'S', '2022-06-19', 'S'),
('09606443930', '11', 'S', '2022-06-19', 'S'),
('09606443930', '12', 'S', '2022-06-19', 'S'),
('09606443930', '13', 'S', '2022-06-19', 'S'),
('09606443930', '14', 'S', '2022-06-19', 'S'),
('09606443930', '15', 'S', '2022-06-19', 'S'),
('20600887049', '01', 'S', '2022-06-19', 'S'),
('20600887049', '02', 'S', '2022-06-19', 'S'),
('20600887049', '03', 'S', '2022-06-19', 'S'),
('20600887049', '04', 'S', '2022-06-19', 'S'),
('20600887049', '05', 'S', '2022-06-19', 'S'),
('20600887049', '06', 'S', '2022-06-19', 'S'),
('20600887049', '07', 'S', '2022-06-19', 'S'),
('20600887049', '08', 'S', '2022-06-19', 'S'),
('20600887049', '09', 'S', '2022-06-19', 'S'),
('20600887049', '10', 'S', '2022-06-19', 'S'),
('20600887049', '11', 'S', '2022-06-19', 'S'),
('20600887049', '12', 'S', '2022-06-19', 'S'),
('20600887049', '13', 'S', '2022-06-19', 'S'),
('20600887049', '14', 'S', '2022-06-19', 'S'),
('20600887049', '15', 'S', '2022-06-19', 'S'),
('20600887049', '16', 'S', '2022-06-19', 'S'),
('20600887049', '17', 'S', '2022-06-19', 'S'),
('20600887049', '18', 'S', '2022-06-19', 'S'),
('00000000191', '02', 'S', '2022-06-19', 'S'),
('00000000191', '03', 'S', '2022-06-19', 'S'),
('00000000191', '04', 'S', '2022-06-19', 'S'),
('00000000191', '05', 'S', '2022-06-19', 'S'),
('00000000191', '06', 'S', '2022-06-19', 'S'),
('00000000191', '07', 'S', '2022-06-19', 'S'),
('00000000191', '08', 'S', '2022-06-19', 'S'),
('00000000191', '09', 'S', '2022-06-19', 'S'),
('00000000191', '10', 'S', '2022-06-19', 'S'),
('00000000191', '11', 'S', '2022-06-19', 'S'),
('00000000191', '12', 'S', '2022-06-19', 'S'),
('00000000191', '13', 'S', '2022-06-19', 'S'),
('00000000191', '14', 'S', '2022-06-19', 'S'),
('00000000191', '15', 'S', '2022-06-19', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `areas`
--

CREATE TABLE `areas` (
  `cdarea` bigint(20) NOT NULL,
  `dearea` varchar(100) DEFAULT NULL,
  `deobse` varchar(1000) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `areas`
--

INSERT INTO `areas` (`cdarea`, `dearea`, `deobse`, `dtcada`, `flativ`) VALUES
(1, 'Salão de Festas', 'Festas', '2022-01-01', 'S'),
(2, 'Churrasqueira 1', 'Churrasco', '2022-01-02', 'S'),
(3, 'Churrasqueira 2', 'Churrasco', '2022-01-03', 'S'),
(4, 'Churrasqueira 3', 'Churrasco', '2022-01-04', 'S'),
(5, 'Quadra Esportiva 1', 'Jogos', '2022-02-05', 'S'),
(6, 'Quadra Esportiva 2', 'Jogos', '2022-02-06', 'S'),
(7, 'Playground', 'Jogos', '2022-01-31', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `arquivos`
--

CREATE TABLE `arquivos` (
  `cdarqu` bigint(20) NOT NULL,
  `dearqu` varchar(100) DEFAULT NULL,
  `decami` varchar(1000) DEFAULT NULL,
  `deobse` varchar(1000) DEFAULT NULL,
  `cdusuo` varchar(14) DEFAULT NULL,
  `cdusud` varchar(14) DEFAULT NULL,
  `cdtipo` char(1) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `arquivos`
--

INSERT INTO `arquivos` (`cdarqu`, `dearqu`, `decami`, `deobse`, `cdusuo`, `cdusud`, `cdtipo`, `dtcada`, `flativ`) VALUES
(2, 'Prestação de Contas - MAIO 2022', 'arquivos/Prestação de contas.pdf', 'Exemplo de prestação de contas', '12345678910', '99999999999', 'P', '2022-06-18', 'S'),
(3, 'Taxa de condomínio - MAIO 2022', 'arquivos/Boleto.pdf', 'Boleto referente a taxa do condomínio do mês de Maio', '12345678910', '06931609939', 'B', '2022-06-18', 'S'),
(5, 'Termo para reserva de salão de festas', 'arquivos/termo salao.pdf', '', '12345678910', '99999999999', 'T', '2022-06-18', 'S'),
(6, 'Ata Reunião 20-05', 'arquivos/Exemplo de Ata.pdf', '', '12345678910', '99999999999', 'A', '2022-06-19', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `avisos`
--

CREATE TABLE `avisos` (
  `cdavis` bigint(20) NOT NULL,
  `deavis` varchar(500) DEFAULT NULL,
  `fllido` char(1) DEFAULT NULL,
  `flmaie` char(1) DEFAULT NULL,
  `cdusuo` varchar(14) DEFAULT NULL,
  `cdusud` varchar(14) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `avisos`
--

INSERT INTO `avisos` (`cdavis`, `deavis`, `fllido`, `flmaie`, `cdusuo`, `cdusud`, `dtcada`, `flativ`) VALUES
(3, 'Exemplo 2 aviso', 'N', 'N', '', '12345678910', '2022-06-18', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `denuncias`
--

CREATE TABLE `denuncias` (
  `cddenu` bigint(20) NOT NULL,
  `dedenu` varchar(1000) DEFAULT NULL,
  `flcanc` char(1) DEFAULT NULL,
  `flreso` char(1) DEFAULT NULL,
  `cdusuo` varchar(14) DEFAULT NULL,
  `cdusud` varchar(14) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `denuncias`
--

INSERT INTO `denuncias` (`cddenu`, `dedenu`, `flcanc`, `flreso`, `cdusuo`, `cdusud`, `dtcada`, `flativ`) VALUES
(1, 'Veículo placa XYZ1235 estacionando sobre a calçada.', 'N', 'S', '12345678910', '12345678910', '2021-03-01', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE `eventos` (
  `cdeven` bigint(20) NOT NULL,
  `deeven` varchar(1000) DEFAULT NULL,
  `fllido` char(1) DEFAULT NULL,
  `flmaie` char(1) DEFAULT NULL,
  `cdusuo` varchar(14) DEFAULT NULL,
  `cdusud` varchar(14) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL,
  `dteven` date NOT NULL,
  `hreven` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`cdeven`, `deeven`, `fllido`, `flmaie`, `cdusuo`, `cdusud`, `dtcada`, `flativ`, `dteven`, `hreven`) VALUES
(1, 'Festa de Confraternização I', 'N', 'N', '12345678910', '12345678910', '2021-12-17', 'S', '2022-12-15', '20:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedores`
--

CREATE TABLE `fornecedores` (
  `cdforn` varchar(14) NOT NULL,
  `deforn` varchar(100) DEFAULT NULL,
  `nrinsc` varchar(20) NOT NULL,
  `deende` varchar(100) DEFAULT NULL,
  `nrende` int(11) DEFAULT NULL,
  `decomp` varchar(100) DEFAULT NULL,
  `debair` varchar(100) DEFAULT NULL,
  `decida` varchar(100) DEFAULT NULL,
  `cdesta` varchar(2) DEFAULT NULL,
  `nrcepi` varchar(8) DEFAULT NULL,
  `demail` varchar(255) DEFAULT NULL,
  `desite` varchar(255) DEFAULT NULL,
  `nrtele` varchar(20) DEFAULT NULL,
  `nrcelu` varchar(20) DEFAULT NULL,
  `decont` varchar(100) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `fornecedores`
--

INSERT INTO `fornecedores` (`cdforn`, `deforn`, `nrinsc`, `deende`, `nrende`, `decomp`, `debair`, `decida`, `cdesta`, `nrcepi`, `demail`, `desite`, `nrtele`, `nrcelu`, `decont`, `dtcada`, `flativ`) VALUES
('06931609939', 'João Vittor Alves Barreto', 'ISENTO', 'Rua Cônego Braga', 97, '', 'Centro', 'Guarapuava', 'PR', '85010050', 'joao.vittorbarreto@gmail.com', NULL, '(00) 0000-0000', '(00) 00000-0000', 'João Vittor', '2022-06-19', 'S'),
('12312312311', 'Suporte Informática', 'Isento', 'Abraham Haick', 407, 'Sala Terreo', 'Santana', 'Guarapuava', 'PR', '85070690', 'supinfo@gmail.com', NULL, '(00) 1234-0000', '(00) 9-1234-0000', 'Joao', '2021-12-31', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `livros`
--

CREATE TABLE `livros` (
  `cdlivr` bigint(20) NOT NULL,
  `delivr` varchar(1000) DEFAULT NULL,
  `fllido` char(1) DEFAULT NULL,
  `flmaie` char(1) DEFAULT NULL,
  `cdusuo` varchar(14) DEFAULT NULL,
  `cdusud` varchar(14) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `livros`
--

INSERT INTO `livros` (`cdlivr`, `delivr`, `fllido`, `flmaie`, `cdusuo`, `cdusud`, `dtcada`, `flativ`) VALUES
(1, 'Vizinho do 504 não respeitando o Horário de Silêncio', 'N', 'N', '12345678910', '12345678910', '2021-03-31', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagar`
--

CREATE TABLE `pagar` (
  `cdpaga` bigint(20) NOT NULL,
  `cdusua` varchar(14) DEFAULT NULL,
  `dtpaga` date DEFAULT NULL,
  `vlpaga` decimal(14,2) DEFAULT NULL,
  `depaga` varchar(100) DEFAULT NULL,
  `refano` char(4) DEFAULT NULL,
  `refmes` char(2) DEFAULT NULL,
  `vldesc` decimal(14,2) DEFAULT NULL,
  `vljuro` decimal(14,2) DEFAULT NULL,
  `vlmult` decimal(14,2) DEFAULT NULL,
  `demens` varchar(100) DEFAULT NULL,
  `vlrece` decimal(14,2) DEFAULT NULL,
  `dtrece` date DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pagar`
--

INSERT INTO `pagar` (`cdpaga`, `cdusua`, `dtpaga`, `vlpaga`, `depaga`, `refano`, `refmes`, `vldesc`, `vljuro`, `vlmult`, `demens`, `vlrece`, `dtrece`, `dtcada`, `flativ`) VALUES
(1, '62173620000180', '2021-01-20', '100.00', 'Taxa de Condomínio', '2021', '01', NULL, NULL, NULL, NULL, '100.00', '2021-01-05', '2021-01-07', 'S'),
(2, '62173620000180', '2021-02-20', '100.00', 'Taxa de Condomínio', '2021', '02', NULL, NULL, NULL, NULL, '100.00', '2021-02-05', '2021-02-07', 'S'),
(3, '62173620000180', '2021-03-20', '100.00', 'Taxa de Condomínio', '2021', '03', NULL, NULL, NULL, NULL, '100.00', '2021-03-05', '2021-03-07', 'S'),
(4, '62173620000180', '2021-04-20', '100.00', 'Taxa de Condomínio', '2021', '04', NULL, NULL, NULL, NULL, '100.00', '2021-04-05', '2021-04-07', 'S'),
(5, '62173620000180', '2021-05-20', '100.00', 'Taxa de Condomínio', '2021', '05', NULL, NULL, NULL, NULL, '100.00', '2021-05-05', '2021-05-07', 'S'),
(6, '62173620000180', '2021-06-20', '100.00', 'Taxa de Condomínio', '2021', '06', NULL, NULL, NULL, NULL, '100.00', '2021-06-05', '2021-06-07', 'S'),
(7, '62173620000180', '2021-07-20', '100.00', 'Taxa de Condomínio', '2021', '07', NULL, NULL, NULL, NULL, '100.00', '2021-07-05', '2021-07-07', 'S'),
(8, '62173620000180', '2021-08-20', '100.00', 'Taxa de Condomínio', '2021', '08', NULL, NULL, NULL, NULL, '100.00', '2021-08-05', '2021-08-07', 'S'),
(9, '62173620000180', '2021-09-20', '100.00', 'Taxa de Condomínio', '2021', '09', NULL, NULL, NULL, NULL, '100.00', '2021-09-05', '2021-09-07', 'S'),
(10, '62173620000180', '2021-10-20', '100.00', 'Taxa de Condomínio', '2021', '10', NULL, NULL, NULL, NULL, '100.00', '2021-10-05', '2021-10-07', 'S'),
(11, '62173620000180', '2021-11-20', '100.00', 'Taxa de Condomínio', '2021', '11', NULL, NULL, NULL, NULL, '100.00', '2021-11-05', '2021-11-07', 'S'),
(12, '62173620000180', '2021-12-20', '100.00', 'Taxa de Condomínio', '2021', '12', NULL, NULL, NULL, NULL, '100.00', '2021-12-05', '2021-12-07', 'S'),
(13, '06931609939', '2022-07-01', '100.00', 'Jardinagem', '2022', '05', '0.00', '0.00', '0.00', '', '100.00', '2022-06-19', '2022-06-19', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `parametros`
--

CREATE TABLE `parametros` (
  `cdclie` varchar(14) NOT NULL,
  `declie` varchar(100) DEFAULT NULL,
  `nrinsc` varchar(20) NOT NULL,
  `deende` varchar(100) DEFAULT NULL,
  `nrende` int(11) DEFAULT NULL,
  `decomp` varchar(100) DEFAULT NULL,
  `debair` varchar(100) DEFAULT NULL,
  `decida` varchar(100) DEFAULT NULL,
  `cdesta` varchar(2) DEFAULT NULL,
  `nrcepi` varchar(8) DEFAULT NULL,
  `demail` varchar(255) DEFAULT NULL,
  `desite` varchar(255) DEFAULT NULL,
  `desere` varchar(255) DEFAULT NULL,
  `demaie` varchar(255) DEFAULT NULL,
  `desene` varchar(255) DEFAULT NULL,
  `nrtele` varchar(20) DEFAULT NULL,
  `nrcelu` varchar(20) DEFAULT NULL,
  `decont` varchar(100) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `parametros`
--

INSERT INTO `parametros` (`cdclie`, `declie`, `nrinsc`, `deende`, `nrende`, `decomp`, `debair`, `decida`, `cdesta`, `nrcepi`, `demail`, `desite`, `desere`, `demaie`, `desene`, `nrtele`, `nrcelu`, `decont`, `dtcada`, `flativ`) VALUES
('12345678910112', 'CondoMais', 'Isento', 'Rua Cônego Braga', 79, '', 'Centro', 'Guarapuava', 'PR', '85010050', 'joao.vittorbarreto@gmail.com', NULL, 'smtp.gmail.com', 'joao.vittorbarreto@gmail.com', 'Senha1238!', '', '(42) 98442-0495', 'João Vittor Alves Barreto', '2022-06-19', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `receber`
--

CREATE TABLE `receber` (
  `cdrece` bigint(20) NOT NULL,
  `cdusua` varchar(14) DEFAULT NULL,
  `dtrece` date DEFAULT NULL,
  `vlrece` decimal(14,2) DEFAULT NULL,
  `derece` varchar(100) DEFAULT NULL,
  `refano` char(4) DEFAULT NULL,
  `refmes` char(2) DEFAULT NULL,
  `vldesc` decimal(14,2) DEFAULT NULL,
  `vljuro` decimal(14,2) DEFAULT NULL,
  `vlmult` decimal(14,2) DEFAULT NULL,
  `demens` varchar(100) DEFAULT NULL,
  `vlpago` decimal(14,2) DEFAULT NULL,
  `dtpago` date DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `receber`
--

INSERT INTO `receber` (`cdrece`, `cdusua`, `dtrece`, `vlrece`, `derece`, `refano`, `refmes`, `vldesc`, `vljuro`, `vlmult`, `demens`, `vlpago`, `dtpago`, `dtcada`, `flativ`) VALUES
(1, '12345678910', '2021-01-10', '101.00', 'Taxa de Condomínio', '2021', '01', NULL, NULL, NULL, NULL, '101.98', '2021-01-09', '2021-01-15', 'S'),
(2, '12345678910', '2021-02-10', '102.00', 'Taxa de Condomínio', '2021', '02', NULL, NULL, NULL, NULL, '102.98', '2021-02-09', '2021-02-15', 'S'),
(3, '12345678910', '2021-03-10', '103.00', 'Taxa de Condomínio', '2021', '03', NULL, NULL, NULL, NULL, '103.98', '2021-03-09', '2021-03-15', 'S'),
(4, '12345678910', '2021-04-10', '104.00', 'Taxa de Condomínio', '2021', '04', NULL, NULL, NULL, NULL, '104.98', '2021-04-09', '2021-04-15', 'S'),
(5, '12345678910', '2021-05-10', '105.00', 'Taxa de Condomínio', '2021', '05', NULL, NULL, NULL, NULL, '105.98', '2021-05-09', '2021-05-15', 'S'),
(6, '12345678910', '2021-06-10', '106.00', 'Taxa de Condomínio', '2021', '06', NULL, NULL, NULL, NULL, '106.98', '2021-06-09', '2021-06-15', 'S'),
(7, '12345678910', '2021-07-10', '107.00', 'Taxa de Condomínio', '2021', '07', NULL, NULL, NULL, NULL, '107.98', '2021-07-09', '2021-07-15', 'S'),
(8, '12345678910', '2021-08-10', '108.00', 'Taxa de Condomínio', '2021', '08', NULL, NULL, NULL, NULL, '108.98', '2021-08-09', '2021-08-15', 'S'),
(9, '12345678910', '2021-09-10', '109.00', 'Taxa de Condomínio', '2021', '09', NULL, NULL, NULL, NULL, '109.98', '2021-09-09', '2021-09-15', 'S'),
(10, '12345678910', '2021-10-10', '110.00', 'Taxa de Condomínio', '2021', '10', NULL, NULL, NULL, NULL, '110.98', '2021-10-09', '2021-10-15', 'S'),
(11, '12345678910', '2021-11-10', '111.00', 'Taxa de Condomínio', '2021', '11', NULL, NULL, NULL, NULL, '111.98', '2021-11-09', '2021-11-15', 'S'),
(12, '12345678910', '2021-12-10', '112.00', 'Taxa de Condomínio', '2021', '12', NULL, NULL, NULL, NULL, '112.98', '2021-12-09', '2021-12-15', 'S'),
(13, '06931609939', '2022-06-17', '110.00', 'Taxa de Condomínio', '2022', '05', '0.00', '0.00', '0.00', '', '0.00', '0000-00-00', '2022-06-19', 'S');

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas`
--

CREATE TABLE `reservas` (
  `cdrese` bigint(20) NOT NULL,
  `cdarea` bigint(20) DEFAULT NULL,
  `cdusua` varchar(14) NOT NULL,
  `dtrese` date DEFAULT NULL,
  `hrrese` int(5) DEFAULT NULL,
  `deobse` varchar(500) DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL,
  `dtcada` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `reservas`
--

INSERT INTO `reservas` (`cdrese`, `cdarea`, `cdusua`, `dtrese`, `hrrese`, `deobse`, `flativ`, `dtcada`) VALUES
(1, 1, '12345678910', '2021-01-31', 18, '', 'S', '2021-01-01'),
(2, 1, '06931609939', '2022-06-27', 20, '', 'S', '2022-06-18'),
(3, 2, '09606443930', '2022-06-30', 21, '', 'S', '2022-06-20'),
(4, 7, '06931609939', '2022-06-29', 20, '', 'P', '2022-06-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `cdusua` char(14) NOT NULL,
  `deusua` varchar(100) DEFAULT NULL,
  `desenh` varchar(100) DEFAULT NULL,
  `demail` varchar(255) DEFAULT NULL,
  `nrrama` varchar(10) NOT NULL,
  `nrtele` varchar(20) DEFAULT NULL,
  `nrcelu` varchar(20) DEFAULT NULL,
  `deloca` varchar(100) DEFAULT NULL,
  `cdtipo` varchar(20) DEFAULT NULL,
  `defoto` varchar(255) DEFAULT NULL,
  `deobse` varchar(500) DEFAULT NULL,
  `dtcada` date DEFAULT NULL,
  `flativ` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`cdusua`, `deusua`, `desenh`, `demail`, `nrrama`, `nrtele`, `nrcelu`, `deloca`, `cdtipo`, `defoto`, `deobse`, `dtcada`, `flativ`) VALUES
('06931609939', 'João Vittor Alves Barreto', 'c5cfeff6712192c94bd37951a0dd80fa', 'joaovittorbarretohaha@gmail.com', '1010', '(00) 0000-0000', '(42) 98442-0495', 'Bloco A, apto 102', 'Morador', 'img/06931609939richa.png', 'Cadastrado pelo próprio morador/condômino.', '2022-06-19', 'S'),
('09606443930', 'Condômino 1', 'e9a1638e69d508634af3b08507539e62', 'teste@gmail.com', '1020', '(00) 0000-0000', '(11) 11111-1111', 'Bloco A, apto 103', 'Morador', 'img/semfoto.jpg', 'Cadastrado pelo próprio morador/condômino.', '2022-06-19', 'S'),
('12345678910', 'Root', '3d9951543dedbc679a2fdcd54d169d68', 'joao.vittor@gmail.com', '0000', '(41) 2341-2342', '(49) 12341-234', 'Quadra A, Casa 404', 'Administrador', 'img/12345678910download (1).png', '', '2022-06-19', 'S'),
('20600887049', 'Administrador', '368f4611a4692990bdc2d35c3f72bb13', 'administrador@gmail.com', '0000', '(00) 0000-0000', '(00) 00000-0000', 'Bloco C, apto 302', 'Administrador', 'img/semfoto.jpg', 'Conta de admin teste', '2022-06-19', 'S');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acessos`
--
ALTER TABLE `acessos`
  ADD KEY `iacessos1` (`cdusua`,`cdmenu`);

--
-- Indexes for table `areas`
--
ALTER TABLE `areas`
  ADD PRIMARY KEY (`cdarea`);

--
-- Indexes for table `arquivos`
--
ALTER TABLE `arquivos`
  ADD PRIMARY KEY (`cdarqu`),
  ADD KEY `iarqu1` (`cdusud`),
  ADD KEY `iarqu2` (`cdusuo`);

--
-- Indexes for table `avisos`
--
ALTER TABLE `avisos`
  ADD PRIMARY KEY (`cdavis`),
  ADD KEY `iavis1` (`cdusuo`),
  ADD KEY `iavis2` (`cdusud`);

--
-- Indexes for table `denuncias`
--
ALTER TABLE `denuncias`
  ADD PRIMARY KEY (`cddenu`),
  ADD KEY `idenu1` (`cdusuo`),
  ADD KEY `idenu2` (`cdusud`);

--
-- Indexes for table `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`cdeven`),
  ADD KEY `ieven1` (`cdusuo`),
  ADD KEY `ieven2` (`cdusud`);

--
-- Indexes for table `fornecedores`
--
ALTER TABLE `fornecedores`
  ADD PRIMARY KEY (`cdforn`);

--
-- Indexes for table `livros`
--
ALTER TABLE `livros`
  ADD PRIMARY KEY (`cdlivr`),
  ADD KEY `ilivr1` (`cdusuo`),
  ADD KEY `ilivr2` (`cdusud`);

--
-- Indexes for table `pagar`
--
ALTER TABLE `pagar`
  ADD PRIMARY KEY (`cdpaga`),
  ADD KEY `ipaga1` (`cdusua`,`refano`,`refmes`);

--
-- Indexes for table `parametros`
--
ALTER TABLE `parametros`
  ADD PRIMARY KEY (`cdclie`);

--
-- Indexes for table `receber`
--
ALTER TABLE `receber`
  ADD PRIMARY KEY (`cdrece`),
  ADD KEY `irece1` (`cdusua`,`refano`,`refmes`);

--
-- Indexes for table `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`cdrese`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`cdusua`),
  ADD KEY `iusua1` (`deusua`),
  ADD KEY `iusua2` (`nrcelu`),
  ADD KEY `iusua3` (`demail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `areas`
--
ALTER TABLE `areas`
  MODIFY `cdarea` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `arquivos`
--
ALTER TABLE `arquivos`
  MODIFY `cdarqu` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `avisos`
--
ALTER TABLE `avisos`
  MODIFY `cdavis` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `denuncias`
--
ALTER TABLE `denuncias`
  MODIFY `cddenu` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `eventos`
--
ALTER TABLE `eventos`
  MODIFY `cdeven` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `livros`
--
ALTER TABLE `livros`
  MODIFY `cdlivr` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pagar`
--
ALTER TABLE `pagar`
  MODIFY `cdpaga` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `receber`
--
ALTER TABLE `receber`
  MODIFY `cdrece` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reservas`
--
ALTER TABLE `reservas`
  MODIFY `cdrese` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

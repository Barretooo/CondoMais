<?php

	include "banco.php";
	include "util.php";

	$cdarea = $_POST["cdarea"];
	$dearea = $_POST["dearea"];
	$deobse = $_POST["deobse"];
	$dtcada = date('Y-m-d');
	$flativ	= 'S';

	$Flag = true;

	if ($Flag == true) {

		//campos da tabela
		$aNomes=array();
		$aNomes[]= "cdarea";
		$aNomes[]= "dearea";
		$aNomes[]= "deobse";
		$aNomes[]= "dtcada";
		$aNomes[]= "flativ";
	
		//dados da tabela
		$aDados=array();
		$aDados[]= $cdarea;
		$aDados[]= $dearea;
		$aDados[]= $deobse;
		$aDados[]= $dtcada;
		$aDados[]= $flativ;

		IncluirDados("areas", $aDados, $aNomes);

		$demens = "Cadastro efetuado com sucesso!";
		$detitu = "CondoMais&copy; | Cadastro de Áreas Comuns";
		$devolt = "areas.php";
		header('Location: mensagem.php?demens='.$demens.'&detitu='.$detitu.'&devolt='.$devolt);
	}

?>